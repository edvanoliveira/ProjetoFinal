<?php
namespace frontend\models;

use yii\base\Model;
use common\models\User;

class SignupForm extends Model
{
    public $username;
    public $email;
    public $password;
    public $repeat_password;
    public $id_curso;

    public function rules()
    {
        return [
            ['username', 'trim'],
            ['username', 'required'],
            ['username', 'unique', 'targetClass' => '\common\models\User', 'message' => 'Esse usuário já existe.'],
            ['username', 'string', 'min' => 2, 'max' => 255],

            ['email', 'trim'],
            ['email', 'required'],
            ['email', 'email'],
            ['email', 'string', 'max' => 255],
            ['email', 'unique', 'targetClass' => '\common\models\User', 'message' => 'Esse e-mail já está cadastrado.'],

            ['id_curso','required'],
            ['repeat_password', 'required'],
            ['repeat_password','compare','compareAttribute' => 'password'],

            ['password', 'required'],
            ['password', 'string', 'min' => 6]
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'Id',
            'username' => 'Nome',
            'email' => 'Endereço de Email',
            'password' => 'Senha',
            'repeat_password' => 'Repita sua senha',
            'id_curso' => 'Curso de Graduação',
        ];
    }    

    public function signup()
    {
        if (!$this->validate()) {
            return null;
        }
        
        $user = new User();
        $user->username = $this->username;
        $user->email = $this->email;
        $user->setPassword($this->password);
        $user->generateAuthKey();
        $user->id_curso = $this->id_curso;
        
        return $user->save() ? $user : null;
    }
}
