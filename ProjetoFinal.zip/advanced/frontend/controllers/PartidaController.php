<?php

namespace frontend\controllers;

use Yii;
use common\models\Partida;
use common\models\Jogada;
use common\models\AcharPartida;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

class PartidaController extends Controller{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $searchModel = new AcharPartida();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    public function actionView($id , $linha = NULL, $coluna = NULL)
    {

        $model = $this->findModel($id);
        if ($model->id_user_1 != Yii::$app->user->id && !$model->id_user_2) {
            $model->id_user_2 = Yii::$app->user->id;
            $model->save();
        }

        if ($linha && $coluna) {
            $jogada_model = new Jogada();
            $jogada_model->id_user = Yii::$app->user->id;
            $jogada_model->id_partida = $id;            
            $jogada_model->linha = $linha;
            $jogada_model->coluna = $coluna;
            $jogada_model->save();
        }

        $jogadas = Jogada::find()->where(['id_partida'=>$id])->orderBy('id ASC')->all();        
        $jogadas_array = [];
        $jogador_da_vez = $model->id_user_1;
        $ultimo_jogador = $model->id_user_2;

        for ($row=0; $row<15; $row++) {
            for ($col=0; $col<15; $col++) {   
                $jogadas_array[$row][$col] = 0;
            }
        }        

        foreach ($jogadas as $jogada) {
            $jogadas_array[$jogada->linha][$jogada->coluna] = $jogada->id_user;
            $ultimo_jogador = $jogada->id_user;
        }

        $vencedor = $this->verificaVencedor($jogadas_array,$ultimo_jogador);
        if ($vencedor) {
            $model->vencedor = $vencedor;
            $model->save();
        }

        if (isset($ultimo_jogador)) {
            if ($ultimo_jogador == $model->id_user_1) $jogador_da_vez = $model->id_user_2;
            else $jogador_da_vez = $model->id_user_1;
        }

        return $this->render('view', [
            'model' => $this->findModel($id),
            'jogadas' => $jogadas_array,
            'jogador_da_vez' => $jogador_da_vez,
            'vencedor' => $vencedor
        ]);
    }

    public function verificaVencedor($jogadas,$jogador) {

        $size = 15;

        for ($row=0; $row<$size; $row++) {
            for ($col=0; $col<$size; $col++) {        
                if ($jogadas[$row][$col] == $jogador) {

                    if (($col+4<15) && ($jogadas[$row][$col+1] == $jogador) && ($jogadas[$row][$col+2] == $jogador) && ($jogadas[$row][$col+3] == $jogador) && ($jogadas[$row][$col+4] == $jogador)) {
                        return $jogador;
                    }
                    if (($row+4<15) && ($jogadas[$row+1][$col] == $jogador) && ($jogadas[$row+2][$col] == $jogador) && ($jogadas[$row+3][$col] == $jogador) && ($jogadas[$row+4][$col] == $jogador)) {
                        return $jogador;
                    }
                    if (($col+4<15) && ($row+4<15) && ($jogadas[$row+1][$col+1] == $jogador) && ($jogadas[$row+2][$col+2] == $jogador) && ($jogadas[$row+3][$col+3] == $jogador) && ($jogadas[$row+4][$col+4] == $jogador)) {
                        return $jogador;
                    }
                    if (($col-4>=0) && ($row+4<15) && ($jogadas[$row+1][$col-1] == $jogador) && ($jogadas[$row+2][$col-2] == $jogador) && ($jogadas[$row+3][$col-3] == $jogador) && ($jogadas[$row+4][$col-4] == $jogador)) {
                        return $jogador;
                    }  
                }
            }
        }

        return 0;

    }

    public function actionCreate()
    {

        $model = Partida::find()
            ->where(['id_user_1'=>Yii::$app->user->id])
            ->andWhere('vencedor IS NULL')
            ->one();

        if (!$model) {
            $model = new Partida();
            $model->id_user_1 = Yii::$app->user->id;
            $model->save();
        } 

        return $this->redirect(['partida/view', 'id' => $model->id]);

    }   

    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        if (($model = Partida::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
