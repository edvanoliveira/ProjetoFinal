<?php

use yii\helpers\Html;
use yii\grid\GridView;

$this->title = 'Partidas';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="partida-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Iniciar Nova Partida', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [

            [
                'attribute'=>'id_user_1',
                'value'=>function($model) {
                    return $model->user1->username;
                }
            ],
            [
                'attribute'=>'id_user_2',
                'value'=>function($model) {
                    return $model->user2->username;
                }
            ],
            [
                'attribute'=>'vencedor',
                'value'=>function($model) {
                    return $model->vencedor0->username;
                }
            ],

            ['class' => 'yii\grid\ActionColumn','template'=>'{view}'],
        ],
    ]); ?>
</div>
