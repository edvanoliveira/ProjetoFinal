<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\Pjax;

$this->title = $model->user1->username . " X ";
$this->title .= $model->user2?$model->user2->username:"...";
$this->params['breadcrumbs'][] = ['label' => 'Partidas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

$this->registerJs('
	setInterval(function() {
		recarregar = document.getElementById("recarregar");
		recarregar.click();
	},3000);
');

?>

<?php Pjax::begin(); ?>
<div class="partida-view">

    <h1><?= Html::encode($this->title) ?></h1>


    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            [
            	'attribute'=>'id_user_1',
            	'value'=>$model->user1->username
            ],
            [
            	'attribute'=>'id_user_2',
            	'value'=>$model->user2?$model->user2->username:"Aguardando Jogador..."
            ],            
            [
            	'attribute'=>'vencedor',
            	'value'=>$model->vencedor?$model->vencedor->username:"Vencedor não definido"
            ],              
        ],
    ]) ?>

    <?= Html::a('Recarregar',['partida/view','id'=>$model->id],['id'=>'recarregar']) ?>

</div>
<?php Pjax::end(); ?>

