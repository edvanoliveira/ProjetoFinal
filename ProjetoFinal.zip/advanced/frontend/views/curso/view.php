<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\Pjax;

$this->title = $model->nome;
$this->params['breadcrumbs'][] = ['label' => 'Cursos', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

$this->registerJs('
    setInterval(function() {
        refresh = document.getElementById("refresh");
        refresh.click();
    },1000);
');

?>
<div class="curso-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Deletar', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Deseja deletar?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'nome',
            'sigla',
            'descricao:ntext',
        ],
    ]) ?>

    <?php Pjax::begin(); ?>
    <?= Html::a('Refresh',['curso/view','id'=>$model->id],['class'=>'btn btn-primary','id'=>'refresh','style'=>'display:none']) ?>
    <?= $hora ?>
    <?php Pjax::end(); ?>

</div>
