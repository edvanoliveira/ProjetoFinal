<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\Pjax;

$this->title = ucfirst($model->username);
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

$this->registerJs('
    setInterval(function(){
        refresh = document.getElementById("refresh");
        refresh.click();
    }, 1000);
');

?>
<div class="user-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Deletar', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Tem certeza que deseja apagar o usuário?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'username',
            'email:email',
            [
            'attribute'=>'id_curso',
            'value'=>$model->curso->nome,
            ],
        ],
    ]) ?>

    <p>
        O Curso de <?= $model->curso->nome ?> possui <?= $users_from_curso ?> usuários cadastrados.
    </p>

    <?php Pjax::begin(); ?>
    <p>
        <?= Html::a("Atualizar", ['user/view','id'=>$model->id], ['class' => 'btn btn-lg btn-primary', 'id' => 'refresh']) ?>
        <?= $data ?>
    </p>
    <?php Pjax::end(); ?>

</div>
