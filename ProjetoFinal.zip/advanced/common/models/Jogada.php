<?php

namespace common\models;

use Yii;

class Jogada extends \yii\db\ActiveRecord
{

    public static function tableName()
    {
        return 'jogada';
    }


    public function rules()
    {
        return [
            [['id_user', 'id_partida'], 'integer'],
            [['datahora'], 'string', 'max' => 45],
            [['id_partida'], 'exist', 'skipOnError' => true, 'targetClass' => Partida::className(), 'targetAttribute' => ['id_partida' => 'id']],
            [['id_user'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id_user' => 'id']],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'Id',
            'id_user' => 'Id Usuário',
            'id_partida' => 'Id Partida',
            'datahora' => 'Data Hora',
        ];
    }


    public function getIdPartida()
    {
        return $this->hasOne(Partida::className(), ['id' => 'id_partida']);
    }

    public function getIdUser()
    {
        return $this->hasOne(User::className(), ['id' => 'id_user']);
    }
}
