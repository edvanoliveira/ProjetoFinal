<?php

namespace common\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Jogada;

class AcharJogada extends Jogada
{

    public function rules()
    {
        return [
            [['id', 'id_user', 'id_partida'], 'integer'],
            [['datahora'], 'safe'],
        ];
    }


    public function scenarios()
    {
    
        return Model::scenarios();
    }

    public function search($params)
    {
        $query = Jogada::find();


        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
         
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'id_user' => $this->id_user,
            'id_partida' => $this->id_partida,
        ]);

        $query->andFilterWhere(['like', 'datahora', $this->datahora]);

        return $dataProvider;
    }
}
