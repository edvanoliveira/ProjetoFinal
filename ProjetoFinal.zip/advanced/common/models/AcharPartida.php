<?php

namespace common\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Partida;

class AcharPartida extends Partida
{
    public function rules()
    {
        return [
            [['id', 'id_user_1', 'id_user_2', 'vencedor'], 'integer'],
        ];
    }

    public function scenarios()
    {
        return Model::scenarios();
    }

    public function search($params)
    {
        $query = Partida::find()->where('Vencedor IS NOT NULL');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'id_user_1' => $this->id_user_1,
            'id_user_2' => $this->id_user_2,
            'vencedor' => $this->vencedor,
        ]);

        return $dataProvider;
    }
}
