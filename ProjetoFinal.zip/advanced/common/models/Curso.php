<?php

namespace common\models;

use Yii;

class Curso extends \yii\db\ActiveRecord
{
    public static function tableName()
    {
        return 'curso';
    }
    public function rules()
    {
        return [
            [['sigla', 'descricao'], 'required', 'message' => 'Este campo é obrigatório'],
            ['nome', 'required', 'message' => 'O campo nome é obrigatório'],
            [['descricao'], 'string'],
            [['nome'], 'string', 'max' => 200],
            [['sigla'], 'string', 'length' => 4, 'notEqual'=>'Precisa ter 4 caracteres'],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nome' => 'Nome',
            'sigla' => 'Sigla',
            'descricao' => 'Descrição',
        ];
    }

    public function getUsers()
    {
        return $this->hasMany(User::className(), ['id_curso' => 'id']);
    }
}