<?php

namespace common\models;

use Yii;

class Partida extends \yii\db\ActiveRecord
{

    public static function tableName()
    {
        return 'partida';
    }

    public function rules()
    {
        return [
            [['id_user_1', 'id_user_2', 'vencedor'], 'integer'],
            [['id_user_1'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id_user_1' => 'id']],
            [['id_user_2'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id_user_2' => 'id']],
            [['vencedor'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['vencedor' => 'id']],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'id_user_1' => 'Jogador 1',
            'id_user_2' => 'Jogador 2',
            'vencedor' => 'Vencedor',
        ];
    }

    public function getJogadas()
    {
        return $this->hasMany(Jogada::className(), ['id_partida' => 'id']);
    }

    public function getUser1()
    {
        return $this->hasOne(User::className(), ['id' => 'id_user_1']);
    }

    public function getUser2()
    {
        return $this->hasOne(User::className(), ['id' => 'id_user_2']);
    }

    public function getVencedor0()
    {
        return $this->hasOne(User::className(), ['id' => 'vencedor']);
    }
}
