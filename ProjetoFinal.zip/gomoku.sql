-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 21-Set-2016 às 09:35
-- Versão do servidor: 5.5.49-0ubuntu0.14.04.1
-- versão do PHP: 5.5.9-1ubuntu4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `gomoku`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `curso`
--

CREATE TABLE IF NOT EXISTS `curso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `sigla` char(4) NOT NULL,
  `descricao` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `curso`
--

INSERT INTO `curso` (`id`, `nome`, `sigla`, `descricao`) VALUES
(1, 'Sistemas de Informação', 'IE15', 'O curso de Bacharelado em Sistemas de Informação é resultado de um processo de consolidação do ensino e pesquisa em Ciência da Computação no norte do país, estando em consonância com as diretrizes estabelecidas pelo Ministério da Educação, Cultura e Desporto - MEC, também atendendo à Nova lei de Diretrizes e Bases da Educação Brasileira.'),
(2, 'Ciência da Computação', 'IE08', 'O curso de Bacharelado em Ciência da Computação é resultado de um processo de consolidação do ensino e pesquisa em Ciência da Computação no norte do país, estando em consonância com as diretrizes estabelecidas pelo Ministério da Educação - MEC, também atendendo à Nova lei de Diretrizes e Bases da Educação Brasileira.');

-- --------------------------------------------------------

--
-- Estrutura da tabela `jogada`
--

CREATE TABLE IF NOT EXISTS `jogada` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_partida` int(11) DEFAULT NULL,
  `linha` int(11) NOT NULL,
  `coluna` int(11) NOT NULL,
  `datahora` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_jogada_1_idx` (`id_partida`),
  KEY `fk_jogada_2_idx` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Extraindo dados da tabela `jogada`
--

INSERT INTO `jogada` (`id`, `id_user`, `id_partida`, `linha`, `coluna`, `datahora`) VALUES
(1, 2, 46, 1, 1, '0000-00-00 00:00:00'),
(2, 3, 46, 1, 7, '0000-00-00 00:00:00'),
(3, 2, 46, 3, 8, '0000-00-00 00:00:00'),
(4, 3, 46, 3, 7, '0000-00-00 00:00:00'),
(5, 2, 46, 3, 5, '0000-00-00 00:00:00'),
(6, 3, 46, 4, 5, '0000-00-00 00:00:00'),
(7, 2, 46, 5, 6, '0000-00-00 00:00:00'),
(8, 3, 46, 5, 6, '0000-00-00 00:00:00'),
(9, 2, 46, 5, 6, '0000-00-00 00:00:00'),
(10, 3, 46, 5, 6, '0000-00-00 00:00:00'),
(11, 2, 46, 5, 6, '0000-00-00 00:00:00'),
(12, 2, 46, 5, 6, '0000-00-00 00:00:00'),
(13, 3, 46, 1, 7, '0000-00-00 00:00:00'),
(14, 2, 46, 1, 7, '0000-00-00 00:00:00'),
(15, 3, 46, 1, 7, '0000-00-00 00:00:00'),
(16, 2, 46, 1, 4, '0000-00-00 00:00:00'),
(17, 3, 46, 1, 4, '0000-00-00 00:00:00'),
(18, 2, 46, 2, 5, '0000-00-00 00:00:00'),
(19, 3, 46, 4, 9, '0000-00-00 00:00:00'),
(20, 2, 46, 5, 9, '0000-00-00 00:00:00'),
(21, 3, 46, 2, 6, '0000-00-00 00:00:00'),
(22, 2, 46, 3, 6, '0000-00-00 00:00:00'),
(23, 3, 46, 2, 6, '0000-00-00 00:00:00'),
(24, 2, 46, 2, 6, '0000-00-00 00:00:00'),
(25, 3, 46, 4, 7, '0000-00-00 00:00:00'),
(26, 2, 46, 4, 6, '0000-00-00 00:00:00'),
(27, 3, 46, 6, 6, '0000-00-00 00:00:00'),
(28, 2, 46, 6, 6, '0000-00-00 00:00:00'),
(29, 2, 47, 1, 10, '0000-00-00 00:00:00'),
(30, 3, 47, 1, 7, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `partida`
--

CREATE TABLE IF NOT EXISTS `partida` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user_1` int(11) DEFAULT NULL,
  `id_user_2` int(11) DEFAULT NULL,
  `vencedor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_partida_1_idx` (`id_user_1`),
  KEY `fk_partida_2_idx` (`id_user_2`),
  KEY `fk_partida_3_idx` (`vencedor`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Extraindo dados da tabela `partida`
--

INSERT INTO `partida` (`id`, `id_user_1`, `id_user_2`, `vencedor`) VALUES
(45, NULL, NULL, NULL),
(46, 2, 3, 2),
(47, 2, 3, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `id_curso` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`),
  KEY `fk_curso` (`id_curso`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`, `id_curso`) VALUES
(2, 'Edvan', '77SG4fP6co0x8z6vD3Ht_etTahLB636q', '$2y$13$VN8FHJHz6YWDdAwcOa6oUuEbH.dxiUnIzwylte1FW2EYFUPVL1ddy', NULL, 'acessoroot@live.com', 10, 1474394328, 1474394328, 1),
(3, 'teste2', 'WuLHcTrgQ8v4uTfM0EbqlOuCwjcfxrhn', '$2y$13$kaTkPTSTUwjd.iy1njb3c.h20YvD49R6a7MO2Fe9JqWnOC1QQDp8m', NULL, 'acessoroot2@live.com', 10, 1474398869, 1474398869, 2);

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `jogada`
--
ALTER TABLE `jogada`
  ADD CONSTRAINT `fk_jogada_1` FOREIGN KEY (`id_partida`) REFERENCES `partida` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_jogada_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `partida`
--
ALTER TABLE `partida`
  ADD CONSTRAINT `fk_partida_1` FOREIGN KEY (`id_user_1`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_partida_2` FOREIGN KEY (`id_user_2`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_partida_3` FOREIGN KEY (`vencedor`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_curso_idx` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
